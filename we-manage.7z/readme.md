# How To Run

1. Install Node
2. Run `npm ci`
3. Run `npm run dev`
4. Yep
