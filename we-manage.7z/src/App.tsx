import QuestionnairePage from "@app-page/questionnaire";
import "./App.css";

function App() {
  return <QuestionnairePage />;
}

export default App;
