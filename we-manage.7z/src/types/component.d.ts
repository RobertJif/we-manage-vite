export type SvgIconProps = {
  className?: string;
  onClick?: React.MouseEventHandler;
};

export type ComponentProps = {
  children?: React.ReactNode;
};
